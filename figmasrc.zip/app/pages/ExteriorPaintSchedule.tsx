import React from 'react';
import { ScheduleLayout } from '../components/ScheduleLayout';

export const ExteriorPaintSchedule: React.FC = () => {
  return (
    <ScheduleLayout title="Selection Schedule: Exterior Paint" pageNumber={3}>
      <h2 className="text-2xl font-semibold text-gray-900 mb-6">Exterior Paint</h2>
      
      <div className="overflow-x-auto">
        <table className="w-full border-collapse border border-gray-300">
          <thead>
            <tr className="bg-gray-100">
              <th className="border border-gray-300 px-4 py-3 text-left text-sm font-semibold text-gray-900">Area</th>
              <th className="border border-gray-300 px-4 py-3 text-left text-sm font-semibold text-gray-900">Color</th>
              <th className="border border-gray-300 px-4 py-3 text-left text-sm font-semibold text-gray-900">Finish</th>
              <th className="border border-gray-300 px-4 py-3 text-left text-sm font-semibold text-gray-900">Supplier/Link</th>
              <th className="border border-gray-300 px-4 py-3 text-left text-sm font-semibold text-gray-900">Notes</th>
            </tr>
          </thead>
          <tbody>
            {/* Example Row */}
            <tr>
              <td className="border border-gray-300 px-4 py-3 text-sm">Siding</td>
              <td className="border border-gray-300 px-4 py-3 text-sm">
                <div className="flex items-center gap-2">
                  <div className="w-10 h-10 bg-slate-600 border border-gray-300 rounded"></div>
                  <span>BM HC-166 Kendall Charcoal</span>
                </div>
              </td>
              <td className="border border-gray-300 px-4 py-3 text-sm">Satin</td>
              <td className="border border-gray-300 px-4 py-3 text-sm">Benjamin Moore</td>
              <td className="border border-gray-300 px-4 py-3 text-sm">Weather-resistant formula</td>
            </tr>
            {/* Empty rows */}
            {Array.from({ length: 10 }).map((_, i) => (
              <tr key={i}>
                <td className="border border-gray-300 px-4 py-3 text-sm h-12"></td>
                <td className="border border-gray-300 px-4 py-3 text-sm"></td>
                <td className="border border-gray-300 px-4 py-3 text-sm"></td>
                <td className="border border-gray-300 px-4 py-3 text-sm"></td>
                <td className="border border-gray-300 px-4 py-3 text-sm"></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div className="mt-6 p-4 bg-gray-50 border border-gray-300 rounded">
        <h3 className="text-sm font-semibold text-gray-900 mb-2">Notes</h3>
        <p className="text-sm text-gray-600">
          All exterior surfaces to be pressure washed and primed before painting. UV-resistant paint required for all sun-exposed areas.
        </p>
      </div>
    </ScheduleLayout>
  );
};
